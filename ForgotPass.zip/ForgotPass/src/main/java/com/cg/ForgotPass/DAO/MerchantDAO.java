package com.cg.ForgotPass.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.ForgotPass.model.Merchant;
@Repository
public interface MerchantDAO extends JpaRepository<Merchant, Integer> {
	
	
	
	@Query("select merchant from Merchant merchant where merchant.mid=:mid")
	  public Merchant getMid(@Param("mid") Integer mid);

}
