package com.cg.ForgotPass.service;

import java.util.List;

import com.cg.ForgotPass.model.Customer;
import com.cg.ForgotPass.model.Merchant;


public interface IForgotPwdService {

		Customer validate(Integer cid);

		Merchant valid(Integer mid);
}
