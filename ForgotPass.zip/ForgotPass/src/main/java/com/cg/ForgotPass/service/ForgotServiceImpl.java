package com.cg.ForgotPass.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ForgotPass.DAO.ForgotPwdDao;
import com.cg.ForgotPass.DAO.MerchantDAO;
import com.cg.ForgotPass.model.Customer;
import com.cg.ForgotPass.model.Merchant;



@Service

public class ForgotServiceImpl implements IForgotPwdService {

	@Autowired ForgotPwdDao dao;
	@Autowired MerchantDAO da;


	@Override
	public Customer validate(Integer cid) {
		// TODO Auto-generated method stub
		return dao.getCid(cid);
	}
	
	@Override
	public Merchant valid(Integer mid) {
		// TODO Auto-generated method stub
		return da.getMid(mid);
		
	}



	
}

