package com.cg.ForgotPass.service;

import java.util.List;

import com.cg.ForgotPass.model.Customer;

public interface IForgotPwdService {

		Customer validate(String email);
		void updatePassword(String email,String newpass, String confirmpass);
		
}
