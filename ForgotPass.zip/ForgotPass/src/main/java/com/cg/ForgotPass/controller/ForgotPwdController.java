package com.cg.ForgotPass.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ForgotPass.model.Customer;
import com.cg.ForgotPass.model.Merchant;
import com.cg.ForgotPass.service.IForgotPwdService;


@RestController
@RequestMapping("/search")
public class ForgotPwdController {
	@Autowired IForgotPwdService service;
	

	
	@GetMapping(value="/{cid}")
	public Customer getData(@PathVariable("cid") Integer cid){
		System.out.println(cid);
		Customer cust = service.validate(cid);
		//System.out.println(cus.getPasswod());
		return cust;
	}
	
	@GetMapping(value="/{mid}")
	public Merchant getData1(@PathVariable("mid") Integer mid){
		System.out.println(mid);
		Merchant mus = service.valid(mid);
	
		return mus;
	}
	
	
}
