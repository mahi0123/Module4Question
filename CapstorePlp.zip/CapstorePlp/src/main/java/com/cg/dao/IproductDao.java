package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.entity.ProductEntity;
@Repository
public interface IproductDao extends JpaRepository<ProductEntity, Integer> {

}
