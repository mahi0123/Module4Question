package com.cg.ForgotPass.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ForgotPass.model.Customer;
import com.cg.ForgotPass.service.IForgotPwdService;


@RestController
@RequestMapping("/forgotpassword")
public class ForgotPwdController {
	@Autowired IForgotPwdService service;
	

	@PostMapping(value="/{email}/{new}/{confirm}")
	public ResponseEntity<String> updatePassword(@PathVariable("email") String email,@PathVariable("new") String newpass,@PathVariable("confirm") String confirmpass){
		System.out.println(email);
		Customer cu = service.validate(email);
		if(newpass.equals(cu.getPasswod()))
		{
			return new ResponseEntity<String>(cu.getCname()+", You Have Entered Your Previous Password",HttpStatus.OK);
		}
		else
			if(!newpass.equals(confirmpass))
			{
				return new ResponseEntity<String>(cu.getCname()+", Passwords Should Match",HttpStatus.OK);
			}
		service.updatePassword(email,newpass,confirmpass);
		//System.out.println(cus.getPasswod());
		return new ResponseEntity<String>(cu.getCname()+" your Password has been Updated",HttpStatus.OK);
	}
	
	
	@GetMapping(value="/validate/{email}")
	public ResponseEntity<String> validateEmail(@PathVariable("email") String email){
		System.out.println(email);
		service.validate(email);
		//System.out.println(cus.getPasswod());
		return new ResponseEntity<String>("Email found",HttpStatus.OK);
	}
	
	
	@GetMapping(value="/{email}")
	public Customer getData(@PathVariable("email") String email){
		System.out.println(email);
		Customer cust = service.validate(email);
		//System.out.println(cus.getPasswod());
		return cust;
	}
	
}
