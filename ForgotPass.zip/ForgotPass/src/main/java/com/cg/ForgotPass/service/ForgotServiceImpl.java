package com.cg.ForgotPass.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ForgotPass.DAO.ForgotPwdDao;
import com.cg.ForgotPass.model.Customer;



@Service

public class ForgotServiceImpl implements IForgotPwdService {

	@Autowired ForgotPwdDao dao;


	@Override
	public Customer validate(String email) {
		// TODO Auto-generated method stub
		return dao.getEmail(email);
	}

	@Override
	public void updatePassword(String email, String newpass, String confirmpass) {
		
		Customer user = validate(email);
		if(dao.existsById(user.getCid()))
		{
			if(newpass.equals(confirmpass))
			{
				user.setPasswod(confirmpass);
				dao.save(user);
			}
		}
		
		
	}

	
	
}

