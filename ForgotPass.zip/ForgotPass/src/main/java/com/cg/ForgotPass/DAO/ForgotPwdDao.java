package com.cg.ForgotPass.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.ForgotPass.model.Customer;



@Repository
public interface ForgotPwdDao extends JpaRepository<Customer, Integer>
// CrudRepository<Customer, Integer>
{
	/*
	 * @Query("select customer from Customer customer where customer.email=:email")
	 * public Customer findByEmail(@Param("email") String email);
	 */
	  @Query("select customer from Customer customer where customer.cid=:cid")
	  public Customer getCid(@Param("cid") Integer cid);
	 
	  
}
