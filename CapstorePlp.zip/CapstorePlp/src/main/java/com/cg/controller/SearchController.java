package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.CustomerEntity;
import com.cg.entity.MerchantEntity;
import com.cg.entity.ProductEntity;
import com.cg.service.IsearchService;





@RestController
@RequestMapping("/cap")
public class SearchController {
	
	@Autowired private IsearchService service;
	@PostMapping(value="/create")
	public ResponseEntity<String>create(@RequestBody CustomerEntity ce){
		service.createCustomer(ce);
		return  new ResponseEntity<String>("Record create",HttpStatus.CREATED);
	}
	
	@GetMapping (value="/search/{cid}")
	public CustomerEntity search(@PathVariable Integer cid) 
	{ 
		
		return service.getCutomerbyId(cid);
		
	}
	
	@PostMapping(value="/create")
	public ResponseEntity<String>create(@RequestBody MerchantEntity me){
		service.addMerchant(me);
		return  new ResponseEntity<String>("Record create",HttpStatus.CREATED);
	}
	
	@GetMapping (value="/{mid}")
	public MerchantEntity searching(@PathVariable Integer mid) 
	{ 
		return service.getMerchantbymid(mid);
		
	}
	
	@PostMapping(value="/create")
	public ResponseEntity<String>create(@RequestBody ProductEntity pe){
		service.addProduct(pe);;
		return  new ResponseEntity<String>("Record create",HttpStatus.CREATED);
	}
	
	@GetMapping (value="/{productid}")
	public MerchantEntity searchprod(@PathVariable Integer productid) 
	{ 
		return service.getMerchantbymid(productid);
		
	}
	
	
	
	
	

}
