package com.cg.service;

import javax.persistence.Id;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICustomerDao;
import com.cg.dao.ImerchantDao;
import com.cg.dao.IproductDao;
import com.cg.entity.CustomerEntity;
import com.cg.entity.MerchantEntity;
import com.cg.entity.ProductEntity;


@Service
public class SearchServiceImpl implements IsearchService{
    
	@Autowired private ICustomerDao cao;
	@Autowired private ImerchantDao mao;
	@Autowired private IproductDao pdo;
	@Transactional
	public void createCustomer(CustomerEntity ce) {
		
		cao.save(ce);
		
	}

	@Transactional
	public CustomerEntity getCutomerbyId(Integer cid) {

		 CustomerEntity ce=	cao.findById(cid).get();
		 System.out.println(ce);
		  return ce;
		
		
	}

	@Transactional
	public void addMerchant(MerchantEntity me) {
		
		mao.save(me);
		
	}

	@Transactional
	public MerchantEntity getMerchantbymid(Integer mid) {
		
		MerchantEntity me=mao.findById(mid).get();
		return me;
	}

	@Transactional
	public void addProduct(ProductEntity pe) {
		pdo.save(pe);
		
	}

	@Transactional
	public ProductEntity getproductbyId(Integer productId) {
		ProductEntity pe=pdo.findById(productId).get();
		return pe;
	}

	

}
