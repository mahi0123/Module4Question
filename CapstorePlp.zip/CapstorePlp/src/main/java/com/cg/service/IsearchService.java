package com.cg.service;

import com.cg.entity.CustomerEntity;
import com.cg.entity.MerchantEntity;
import com.cg.entity.ProductEntity;

public interface IsearchService {
	
	public void createCustomer(CustomerEntity ce);
	
	public CustomerEntity getCutomerbyId(Integer cid);
	
	public void addMerchant(MerchantEntity me);
	
	public MerchantEntity  getMerchantbymid(Integer mid);
	
	public void addProduct(ProductEntity pe);
	
	public ProductEntity getproductbyId(Integer productId);

}
