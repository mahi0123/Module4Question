package com.cg.entity;

import java.util.Date;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity

@Table(name="merchant")
public class MerchantEntity {
	
	 @Id
     @GeneratedValue(strategy = GenerationType.AUTO)
     private Integer Mid;
      private String Mname;
      private String email;
      private String password;
      private String catogory;
      private String productName;
      private Date date;
      
      
	public int getMid() {
		return Mid;
	}
	public void setMid(int mid) {
		Mid = mid;
	}
	public String getMname() {
		return Mname;
	}
	public void setMname(String mname) {
		Mname = mname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCatogory() {
		return catogory;
	}
	public void setCatogory(String catogory) {
		this.catogory = catogory;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
      
      
  public MerchantEntity() {
	  
  }
public MerchantEntity(int mid, String mname, String email, String password, String catogory, String productName,
		Date date) {
	super();
	Mid = mid;
	Mname = mname;
	this.email = email;
	this.password = password;
	this.catogory = catogory;
	this.productName = productName;
	this.date = date;
}

@Override
public String toString() {
	return "MerchantEntity [Mid=" + Mid + ", Mname=" + Mname + ", email=" + email + ", password=" + password
			+ ", catogory=" + catogory + ", productName=" + productName + ", date=" + date + "]";
}
  
  
	

}
