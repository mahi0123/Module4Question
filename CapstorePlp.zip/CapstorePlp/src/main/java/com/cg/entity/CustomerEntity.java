package com.cg.entity;

import java.util.Date;

import javax.persistence.*;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity


@Table(name="customer")
public class CustomerEntity {
	
	 @Id

	 @GeneratedValue(strategy = GenerationType.AUTO)
     
	 @Column(name="cid")
	 private Integer cid;

	 @Column(name="cname")
      private String cname;
    @Column(name="cmobilenumber")
    private String mobileNumber;
     @Column(name="cemail")
      private String email;
     @Column(name="password")
      private String passwod;
      @Column(name="created date")
       private Date date;
      @Column(name="logintime")
      private Date loginTime;
       @Column(name="logouttime")
       private Date logoutTime;
       @Column(name="referencenumber")
       private int refNumber;
       
       
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPasswod() {
		return passwod;
	}
	public void setPasswod(String passwod) {
		this.passwod = passwod;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Date getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}
	public Date getLogoutTime() {
		return logoutTime;
	}
	public void setLogoutTime(Date logoutTime) {
		this.logoutTime = logoutTime;
	}
	public int getRefNumber() {
		return refNumber;
	}
	public void setRefNumber(int refNumber) {
		this.refNumber = refNumber;
	}

	
	 public CustomerEntity() {
		// TODO Auto-generated constructor stub
	}
	 
	public CustomerEntity(int cid, String cname, String mobileNumber, String email, String passwod, Date date,
			Date loginTime, Date logoutTime, int refNumber) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.passwod = passwod;
		this.date = date;
		this.loginTime = loginTime;
		this.logoutTime = logoutTime;
		this.refNumber = refNumber;
	}
	@Override
	public String toString() {
		return "CustomerEntity [cid=" + cid + ", cname=" + cname + ", mobileNumber=" + mobileNumber + ", email=" + email
				+ ", passwod=" + passwod + ", date=" + date + ", loginTime=" + loginTime + ", logoutTime=" + logoutTime
				+ ", refNumber=" + refNumber + "]";
	}
	 
	 
       
     

	
	

}
