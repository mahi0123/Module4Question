package com.cg.entity;

import javax.persistence.*;

@Table(name="products")
public class ProductEntity {
	
	@Id
	@Column(name="productid")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer productId;
	@Column(name="productname")
	private String productName;
	@Column(name="productcategory")
	private String productCategory;
	
	public ProductEntity() {
		// TODO Auto-generated constructor stub
	}

	public ProductEntity(int productId, String productName, String productCategory) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCategory = productCategory;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	
	@Override
	public String toString() {
		return "ProductEntity [productId=" + productId + ", productName=" + productName + ", productCategory="
				+ productCategory + "]";
	}
	
	
	
	
	
	

}
